module.exports = {
  mongoURI: "mongodb://Jon:jonjon11@ds231991.mlab.com:31991/social-media-db",
  secretOrKey: "secret"
};
